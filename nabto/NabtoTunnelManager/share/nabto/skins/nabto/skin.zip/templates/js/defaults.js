$(document).on("mobileinit", function() {
  $.ajaxSetup({ cache: false });
  $.ajaxSetup({ isLocal: true });
});
