function getHTTPObject() {
   var http = false;
   // try IE's ActiveX 
   if (typeof ActiveXObject != 'undefined') {
       try {
           http = new ActiveXObject("Msxml2.XMLHTTP");
       } catch (e) {
           try {
               http = new ActiveXObject("Microsoft.XMLHTTP");
           } catch (e2) {
               http = false;
           }
       }
   } else if (XMLHttpRequest) {
       // if ActiveX is not available, use the XMLHttpRequest of Firefox/Mozilla etc. to load the document.
       try {
           http = new XMLHttpRequest();
       } catch (e) {
           http = false;
       }
   }
   return http;
}
