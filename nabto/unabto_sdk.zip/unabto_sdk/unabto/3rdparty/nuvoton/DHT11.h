extern void Init_DHT11(void);
extern void Read_DHT11(uint16_t DHT11[]);
