globalStrings_["_discover_devices_found"] = {
    "en": "The following devices were found on your local network",
    "da": "Lokale enheder fundet",
    "fr": "Périphérique locaux trouvés",
    "it": "Dispositivi locali trovato",
    "de": "Lokale Geräte gefunden",
    "es": "Dispositivos locales encontraron",
    "el": "Τοπικές συσκευές που βρέθηκαν",
    "nl": "Lokale apparaten gevonden",
    "cs": "Místní zařízení nalezeno"
};

globalStrings_["_discover_localdevices"] = {
    "en": "Local devices",
    "da": "Lokale enheder"
};

globalStrings_["_discover_devices_none"] = {
    "en": "No devices found",
    "da": "Ingen enheder fundet",
    "fr": "Aucun périphérique trouvé",
    "it": "Nessun dispositivo trovato",
    "de": "Keine Geräte gefunden",
    "es": "No se encuentran los dispositivos",
    "el": "Δεν βρέθηκαν συσκευές",
    "nl": "Geen apparaten gevonden",
    "cs": "Žádné zařízení nalezeno"
};
globalStrings_["_discover_refresh"] = {
    "en": "Refresh",
    "da": "Opdater",
    "fr": "Rafraîchir",
    "it": "Rinfrescare",
    "de": "Erfrischen",
    "es": "Refrescar",
    "el": "Ανανέωση",
    "nl": "Verversen",
    "cs": "Obnovit",
};
