//;*****************************************************
//;Company :   rakwireless
//;File Name : rak_read_restoreConfig.c
//;Author :    Junhua
//;Create Data : 2014-01-12
//;Last Modified : 
//;Description : RAK415 WIFI UART  DRIVER
//;Version :    1.0.5
//;update url:  www.rakwireless.com
//;****************************************************


#include "BSP_Driver.h"

/*=============================================================================*/
/**
 * @fn           int16 rak_read_restoreConfig(void)
 * @brief        UART, rak_read_restoreConfig 
 * @param[in]    none 
 * @param[out]   none
 * @return       errCode
 *               -1 = Module s busy 
 *               0  = SUCCESS
 * @section description  
 * 
 */
 /*=============================================================================*/
int8 rak_read_restoreConfig(void)
{
	int8	     retval=0;
	char rak_sendCmd[30]="";
	strcpy(rak_sendCmd,RAK_READ_RCONFIG_CMD);
	strcat(rak_sendCmd,RAK_END);
    retval=rak_UART_send((uint8_t*)rak_sendCmd,strlen(rak_sendCmd));//���ʹ�ģ������ӿ�����
	return retval;
}

