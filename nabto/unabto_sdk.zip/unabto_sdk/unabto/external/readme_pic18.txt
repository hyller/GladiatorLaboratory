Please copy or link to Microchips TCP/IP stack version 5 (NOT version 6) here.
The TCP/IP stack can be downloaded from Microchips website http://www.microchip.com/pagehandler/en-us/devtools/mla/ under "Legacy MLA".

Windows:
	mklink /J Microchip <install path>
	Install path will be something like "C:\microchip_solutions_v2013-06-15\Microchip"
	
Linux:
	ln -s <install path> .
	Install path will be something like "~/microchip_solutions_v2013-06-15/Microchip/"